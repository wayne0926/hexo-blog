=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
WinSnap v5.0 for Microsoft Windows XP/Vista/7/8/10
Copyright (c) 2005-2019 NTWind Software
http://www.ntwind.com/software/winsnap.html
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


Introduction
============

WinSnap is a clean, fast, simple and user-friendly utility for taking and 
editing screenshots. It can easily capture windows of non-rectangular form with 
customized and transparent backgrounds, including Aero Glass on Windows 7 and 
Vista. WinSnap adds eye-candy drop shadows, reflections, rotations, watermarks 
and other effects on the fly. It supports a variety of image formats and 
provides advanced auto-save features.


Main features
=============

[+] Flexible screen capture capabilities
[+] Built-in image editor: arrows, rectangles, text annotations
[+] Designed to capture Windows Aero with clean background
[+] Support of transparency in PNG and TIFF image formats
[+] Advanced auto-save and auto-copy options
[+] Usual keyboard and mouse control (Print Screen replacement)
[+] Configurable Tools menu to open external image editors
[+] Small and fast for an image editor, smaller than Paint
[+] Multilingual user interface (Unicode based)


System requirements
===================

WinSnap was especially developed for Microsoft Windows XP/Vista/7/8 and newer 
operating systems. Older versions of Windows are not supported!


Credits
=======

The main application icon is used with permission from FOOOD's Icons 
(http://www.foood.net/). Some icons are from Fugue and Diagona icon sets by 
Yusuke Kamiyamane (http://p.yusukekamiyamane.com/).


Feedback
========

To post any comments and bug reports, use certain forums at:
http://www.ntwind.com/forum/


Thank you for using WinSnap!

--
Alexander Avdonin

Web: http://www.ntwind.com
Email: alexander@ntwind.com
